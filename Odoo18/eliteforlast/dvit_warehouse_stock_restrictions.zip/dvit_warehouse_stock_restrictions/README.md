Warehouse Restriction
========================
- This module will add Warehouse and Stock Location, Pickings, Picking types, Restriction on Users

Installation
============
- Install the module normally like other modules.

Configuration
=============
- Check the restrict warehouses option on the user Configuration.
- Add Default Warehouse Operations and Allowed Stock Locations and you are ready to go.

Note
====
- This restrictions are created using rule and access rights, so it will have no effect on the Adminstrator.

For Support :
=============
* Website : www.dvit.me
* Facebook : www.fb.me/dvit.me
* Twitter : www.twitter.com/dvitme/
* Youtube: www.youtube.com/dvitmech
